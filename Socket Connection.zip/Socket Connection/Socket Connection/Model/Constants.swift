//
//  Constants.swift
//  Socket Connection
//
//  Created by Mac on 5/8/17.
//  Copyright © 2017 AtulPrakash. All rights reserved.
//

import Foundation

let kSocketUrl = "http://ios-test.us-east-1.elasticbeanstalk.com"
let kSocketEvent = "capture"
let kSocketNamespace = "/random"
